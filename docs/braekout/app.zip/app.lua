--[[ (c) mg ]]

require "boot.lib"
tween = require "boot.tween"
local tl = require 'types.tl'
tl.loader()

require "game.breakout"