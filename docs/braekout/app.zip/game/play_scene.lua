

require("game.types")
require("game.data")

local utils = require("game.utils")

local M = {}



local BRICK_NUMROWS = 1
local BRICK_NUMCOLS = 3
local BRICK_DX = 10
local BRICK_DY = 6
local BRICK_W = math.floor((CW - 2 * BRICK_DX) / (BRICK_NUMCOLS)) - BRICK_DX
local BRICK_H = 8


local function increase_difficulty()
   if (BRICK_NUMCOLS < 9) then
      BRICK_NUMCOLS = BRICK_NUMCOLS + 2
   end
   if BRICK_NUMROWS < 5 then
      if BRICK_NUMCOLS % 2 == 1 then
         BRICK_NUMROWS = BRICK_NUMROWS + 1
      end
   end

   BRICK_W = math.floor((CW - 2 * BRICK_DX) / (BRICK_NUMCOLS)) - BRICK_DX
end


local State = {
   points = 0,
   lvl_points = 0,
   paddle_speed = 100.,
   ball_speed = 45.,
}

local Paddle = {}






local Ball = {}










local Bricks = {}

local Walls = {}

local function init_walls()


   Walls[1] = { x = 0, y = 0, w = WALL_THICK, h = CH }

   Walls[2] = { x = 0, y = 0, w = CW, h = WALL_THICK }

   Walls[3] = { x = CW - WALL_THICK, y = 0, w = WALL_THICK, h = CH }

   Walls[4] = { x = 0, y = CH - WALL_THICK, w = CW, h = WALL_THICK }
end

local function init_bricks()
   local b = 1
   for y = 1, BRICK_NUMROWS do
      for x = 1, BRICK_NUMCOLS do
         Bricks[b] = {
            active = true,
            x = (x - 1) * (BRICK_W + BRICK_DX) + BRICK_DX * 3 / 2,
            y = (y - 1) * (BRICK_H + BRICK_DY) + 10 * BRICK_DY,
            w = BRICK_W,
            h = BRICK_H,
            r = 1, g = 1, b = 1,
         }
         b = b + 1
      end
   end

end

local function init_paddle_and_ball()
   Paddle.x = 40
   Paddle.y = CH - 30
   Paddle.w = 30, 0
   Paddle.h = 3

   Ball.x = Paddle.x + Paddle.w / 2.
   Ball.y = Paddle.y - 20
   Ball.x1 = Paddle.x + Paddle.w / 2.
   Ball.y1 = Paddle.y - 20
   Ball.w = 32 / 4
   Ball.h = 32 / 4
   Ball.vx = 2.0
   Ball.vy = -1.6
   print("Paddle and ball initialized")
end


function M.init()
   init_paddle_and_ball()
   init_walls()
   init_bricks()
   State.lvl_points = 0
end



local function update_paddle(DT)
   local speed = State.paddle_speed * DT
   if is_keydown("a") or is_keydown("left") or is_gamepaddown(0, "but_dpad_left") then Paddle.x = Paddle.x - speed end
   if is_keydown("d") or is_keydown("right") or is_gamepaddown(0, "but_dpad_right") then Paddle.x = Paddle.x + speed end

   local paddle_delta = 1
   if Paddle.x < 0 + paddle_delta then Paddle.x = 0 + paddle_delta end
   if Paddle.x >= CW - Paddle.w - paddle_delta + 3 then Paddle.x = CW - Paddle.w - paddle_delta + 3 end
end

local function update_ball(DT)
   local speedx = Ball.vx * DT * State.ball_speed
   local speedy = Ball.vy * DT * State.ball_speed
   Ball.x1 = Ball.x
   Ball.y1 = Ball.y
   Ball.x = Ball.x + speedx
   Ball.y = Ball.y + speedy

   local num_bricks_left = 0


   for _, wall in ipairs(Walls) do
      local c, hor, ver = utils.rect_collision(Ball, wall)
      if c then
         print("*** wall -- " .. tostring(hor) .. " | " .. tostring(ver))
         Ball.y = Ball.y1
         Ball.x = Ball.x1
         if hor then
            Ball.vy = Ball.vy * -1
         end
         if ver then
            Ball.vx = Ball.vx * -1
         end
      end
   end


   for _, brick in ipairs(Bricks) do
      if brick.active then
         local c, hor, ver = utils.rect_collision(Ball, brick)
         if c then
            brick.active = false
            State.points = State.points + 1
            State.lvl_points = State.lvl_points + 1
            if hor then
               Ball.y = Ball.y - speedy / 2
               Ball.vy = Ball.vy * -1
            end
            if ver then
               Ball.x = Ball.x - speedx / 2
               Ball.vx = Ball.vx * -1
            end
         else
            num_bricks_left = num_bricks_left + 1
         end
      end
   end



   do
      local c, hor, ver = utils.rect_collision(Ball, Paddle)
      if c then
         print("+++ paddle -- " .. tostring(hor) .. " | " .. tostring(ver))
         if hor then
            Ball.y = Ball.y - speedy / 2
            Ball.vy = Ball.vy * -1
         end
         if ver then
            Ball.x = Ball.x - speedx / 2
            Ball.vx = Ball.vx * -1
         end
      end
   end


   if Ball.x - Ball.w / 2 <= 0 or Ball.x >= CW - Ball.w / 2 then
      Ball.x = Ball.x - 1.5 * Ball.vx * DT * State.ball_speed
      Ball.vx = Ball.vx * -1
   end
   if Ball.y - Ball.h / 2 <= 0 or Ball.y >= CH - Ball.h / 2 then
      Ball.y = Ball.y - 1.5 * Ball.vy * DT * State.ball_speed
      Ball.vy = Ball.vy * -1
   end

   if num_bricks_left == 0 then
      increase_difficulty()
      M.init()
      set_scene("menu")
   end

end


function M.update(DT)
   update_paddle(DT)
   update_ball(DT)
end

function M.draw()
   clear(0, 0, 0, 1)


   set_color(0.9, 0.6, 0.5, 1)
   draw_text("Level: 1", 10, -TOP_SPACE)
   utils.draw_text_rightaligned("Points: " .. State.points, CW - 10, -TOP_SPACE)

   set_color(0.4, 0.6, 0.4, 1)
   utils.draw_text_centered(string.rep('|', State.lvl_points), CW / 2, -TOP_SPACE + 16 + 8)


   set_color(0.5, 0.4, 0.5, 1)
   draw_rect_filled(Paddle.x, Paddle.y, Paddle.w, Paddle.h)


   push_matrix()
   translate(Ball.x - 16, Ball.y - 16)
   scale_at(1 / 4, 1 / 4, 32 / 2, 32 / 2)
   draw_imagerect(Assets.img_balzie, 16, 16, 32 * (math.random(0, 3)), 0, 32, 32)
   pop_matrix()


   local b = 1
   for y = 1, BRICK_NUMROWS do
      for x = 1, BRICK_NUMCOLS do
         local v = Bricks[b];
         if (v.active) then
            set_color(v.r, v.g, v.b, 1.0)
         else
            set_color(v.r, v.g, v.b, 0.15)
         end
         draw_rect_filled(v.x, v.y, v.w, v.h)
         b = b + 1
      end
   end


   for _, wall in ipairs(Walls) do
      set_color(0.5, 0.6, 0.5, 1)
      draw_rect_filled(wall.x, wall.y, wall.w, wall.h)

   end

end



return M
