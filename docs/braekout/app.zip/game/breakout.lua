



require("game.types")
require("game.data")


local play_scene = require("game.play_scene")
local menu_scene = require("game.menu_scene")

current_scene = "menu"

local function load_assets()
   Assets.font2 = load_font("/assets/fonts/m5x7.ttf", 16)
   Assets.font1 = load_font("/assets/fonts/DroidSerif-Regular.ttf", 16)
   Assets.img_gun = load_image("/assets/images/yellowgun.png")
   Assets.img_balzie = load_image("/assets/images/balzie4x1.png")
end

local function debug_draw(DT)
   set_color(1, 1, 1, 1)
   draw_text("FPS: " .. mathx.round(1 / DT, 2), 5, 0)
   draw_text("DT: " .. mathx.round(DT, 4), 5, 15)


   draw_rect(1, 1, Window.width - 1, Window.height - 1)


   set_color(1, 1, 1, 0.4)
   translate(math.floor((Window.width - CW * Window.scale) / 2) - 0.5, math.floor((Window.height - (CH + TOP_SPACE) * Window.scale) / 2) - 0.5)
   draw_rect(0, 0, mathx.round(CW * Window.scale), mathx.round((CH + TOP_SPACE) * Window.scale))

end

local function adjust_scale()
   local sc = (math.min(Window.width / CW, Window.height / (CH + TOP_SPACE)))
   if Window.PIXEL_PERFFECT then
      Window.scale = math.floor(sc)
   else
      Window.scale = sc
   end
end


function frame(delta_time, width, height, resized, fullscreen)
   if resized then
      Window.width = width
      Window.height = height
      Window.fullscreen = fullscreen
      adjust_scale()
   end



   if is_keypressed("f4") or is_gamepadpressed(0, "but_back") then quit() end
   if is_keypressed("f11") or is_gamepadpressed(0, "but_start") then set_fullscreen(not fullscreen) end
   if is_keypressed("f10") then
      Window.DRAW_DEBUG = not Window.DRAW_DEBUG





   end
   if (is_keydown('left_alt') or is_keydown('right_alt')) and is_keypressed("f12") then
      Window.PIXEL_PERFFECT = not Window.PIXEL_PERFFECT
      adjust_scale()
   end






   if current_scene == "menu" then
      menu_scene.update(delta_time)
   elseif current_scene == "play" then
      play_scene.update(delta_time)
   else
      error("Unknown scene to update: " .. current_scene)
   end


   set_canvas(Window.canvas)
   push_matrix()
   translate(0, (TOP_SPACE))
   if current_scene == "menu" then
      menu_scene.draw()
   elseif current_scene == "play" then
      play_scene.draw()
   else
      error("Unknown scene to draw: " .. current_scene)
   end
   pop_matrix()
   reset_canvas()







   push_matrix()
   if Window.DRAW_DEBUG then
      clear(0.15, 0.15, 0.15, 1)
   else
      clear(0, 0, 0, 1)
   end
   translate(0.5, (CH + TOP_SPACE) * Window.scale + 0.5);
   scale(Window.scale, -Window.scale)
   draw_image(Window.canvas.image, math.floor(Window.width / Window.scale / 2 - CW / 2), math.floor(-Window.height / Window.scale / 2 + (CH + TOP_SPACE) / 2))
   pop_matrix()


   if Window.DRAW_DEBUG then
      push_matrix()
      debug_draw(delta_time)
      pop_matrix()
   end
end


local function init()
   set_margins(1, 1, 1, 1)
   set_paddings(10, 10, 20, 40)
   Window.width = get_windowwidth()
   Window.height = get_windowheight()
   Window.canvas = new_canvas(CW, (CH + TOP_SPACE))
   adjust_scale()

   load_assets()

   set_font(Assets.font1)
   menu_scene.init()
   play_scene.init()
end

init()
