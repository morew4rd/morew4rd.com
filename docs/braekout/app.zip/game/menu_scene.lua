

require("game.types")
require("game.data")
local utils = require("game.utils")

local M = {}

local st = {
   alpha = 0.0,
}

local tweens = {}


local menu_items = {
   { title = "Continue Game" },
   { title = "New Game" },
   { title = "Music Magic mu ma mi MI Mla [] ||||||||" },
   { title = "Effects MALI MULI MXA [] |||||" },
   { title = "Quit" },
}

local active_item = 1

function M.init()
   st.alpha = 0.0
   set_font(Assets.font1)
   tweens.goin = tween.new(1.0, st, { alpha = 1.0 }, 'inOutQuad')
   tweens.demo_starter = tween.new(10.0, st, {}, 'inOutQuad')
   active_item = 1
end

function M.update(dt)
   local _goin_done = tweens.goin:update(dt)
   if tweens.demo_starter then
      local demostarter_done = tweens.demo_starter:update(dt)
      if demostarter_done then
         M.init()
         print("AUTO START THE GAME (FOR DEMO MODE/TESTING)")
         set_scene("play")
      end
   end

   if tweens.goout then
      local goout_done = tweens.goout:update(dt)
      if goout_done then
         M.init()
         tweens.goout = nil
         set_scene("play")
      end
   end

   if is_keypressed("space") or is_gamepadpressed(0, "but_a") then
      tweens.demo_starter = nil
      tweens.goin:set(10.0)
      tweens.goout = tween.new(0.4, st, { alpha = 0.0 }, 'inOutQuad')
   end

   if is_keypressed("up") or is_gamepadpressed(0, "but_dpad_up") then
      tweens.demo_starter = nil
      active_item = active_item - 1
   end
   if is_keypressed("down") or is_gamepadpressed(0, "but_dpad_down") then
      tweens.demo_starter = nil
      active_item = active_item + 1
   end

   if active_item < 1 then active_item = 1 end
   if active_item > #menu_items then active_item = #menu_items end

end


function M.draw()
   clear(0, 0, 0, 1)
   draw_image(Assets.img_gun, CW / 2 - Assets.img_gun.width / 2, -25)
   set_color(1, 1, 1, st.alpha)
   utils.draw_text_centered("BRAEKOUT", CW / 2, 0)
   for i = 1, #menu_items do
      local mi = menu_items[i]
      if i == active_item then
         set_color(1, 1, 0, 1)
      else
         set_color(0.7, 0.7, 0.7, 0.7)
      end
      draw_text(mi.title, CW / 2 - 50, (40 + i * 20))
   end
end


return M
