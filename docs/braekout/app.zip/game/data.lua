


TOP_SPACE = 40.0
CW = 128.0 * 2 * 1
CH = 80.0 * 2 * 2 - TOP_SPACE
WALL_THICK = 5

 SceneName = {}




function set_scene(name)
   (_G)["current_scene"] = name
end


Window = {
   width = 0.,
   height = 0.,
   fullscreen = false,
   scale = 1.,
   canvas = nil,
   DRAW_DEBUG = false,
   PIXEL_PERFFECT = true,
}

Assets = {
   font1 = nil,
   font2 = nil,
   img_gun = nil,
   img_balzie = nil,
}
